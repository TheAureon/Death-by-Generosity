// ===========================================================================
// ITEMS — everything the hero can carry and give away.
//
//   "slot"  : where it's worn: weapon, armor, helmet, shield, cape
//             ("material" = monster bits for crafting; can't be worn)
//   "stack" : true = many of them share one bag slot
//   "stats" : what it adds to whoever wears it (attack, defense, maxHp, speed)
//   "art"   : how it's drawn. "type" picks the shape (see the list below),
//             "color" is the main colour, "trim" the second colour.
//
// Shapes:  weapon: sword, axe, club, spear, staff, pan, fish
//          armor : plate, leather, robe
//          helmet: helm, hat, crown, pot, tophat
//          shield: round, kite, door
//          cape  : cape
//          material: goo, feather, hide, tusk, pelt, shell, ember, scale, shard
// ===========================================================================
DBG.data.items = {
  "rusty_sword": {
    "name": "Rusty Sword", "slot": "weapon",
    "art": { "type": "sword", "color": "#b07a5a", "trim": "#6b4428" },
    "stats": { "attack": 5 },
    "description": "Mostly rust. Some sword."
  },
  "legendary_sword": {
    "name": "Legendary Sword of Mild Inconvenience", "slot": "weapon",
    "art": { "type": "sword", "color": "#bfe8ff", "trim": "#f2c14e" },
    "stats": { "attack": 400 },
    "description": "Forged in dragonfire. Mostly used to open jars."
  },
  "war_axe": {
    "name": "Big War Axe", "slot": "weapon",
    "art": { "type": "axe", "color": "#c3c8cf", "trim": "#7a5232" },
    "stats": { "attack": 120, "speed": -5 },
    "description": "Heavy. Sharp. Has 'NO REFUNDS' carved on the handle."
  },
  "frying_pan": {
    "name": "Frying Pan", "slot": "weapon",
    "art": { "type": "pan", "color": "#3a3a44", "trim": "#7a5232" },
    "stats": { "attack": 25 },
    "description": "Still has a bit of egg on it. Adds flavour to violence."
  },
  "wet_fish": {
    "name": "Slightly Wet Fish", "slot": "weapon",
    "art": { "type": "fish", "color": "#7fa7c9", "trim": "#e8505b" },
    "stats": { "attack": 3 },
    "description": "It's a fish. It's wet. You're welcome."
  },
  "wizard_staff": {
    "name": "Wizard Staff", "slot": "weapon",
    "art": { "type": "staff", "color": "#8a5a2b", "trim": "#7cf0ff" },
    "stats": { "attack": 60, "maxHp": 20 },
    "description": "The gem hums. Nobody knows what it does. Neither does the gem."
  },
  "pointy_spear": {
    "name": "Pointy Spear", "slot": "weapon",
    "art": { "type": "spear", "color": "#c3c8cf", "trim": "#a8814f" },
    "stats": { "attack": 45 },
    "description": "The pointy end goes toward the hero. Usually."
  },
  "smith_hammer": {
    "name": "Forge Hammer", "slot": "weapon",
    "art": { "type": "club", "color": "#55555f", "trim": "#7a5232" },
    "stats": { "attack": 30 },
    "description": "For hitting hot metal. Or hot heroes. Mostly metal."
  },
  "leather_vest": {
    "name": "Leather Vest", "slot": "armor",
    "art": { "type": "leather", "color": "#8a5a2b", "trim": "#c99560" },
    "stats": { "defense": 10 },
    "description": "Smells like a cow. Protects like a cow."
  },
  "plate_armor": {
    "name": "Spare Plate Armour", "slot": "armor",
    "art": { "type": "plate", "color": "#c3c8cf", "trim": "#6c717b" },
    "stats": { "defense": 150, "speed": -10 },
    "description": "Your old armour, from before the curse. It misses you."
  },
  "wizard_robe": {
    "name": "Wizard Robe", "slot": "armor",
    "art": { "type": "robe", "color": "#5b4bc4", "trim": "#f6d743" },
    "stats": { "defense": 5, "maxHp": 50 },
    "description": "Has stars on it. Makes you 40% more mysterious."
  },
  "iron_helm": {
    "name": "Iron Helmet", "slot": "helmet",
    "art": { "type": "helm", "color": "#9aa0a8", "trim": "#6c717b" },
    "stats": { "defense": 30 },
    "description": "A bucket with ambition."
  },
  "straw_hat": {
    "name": "Straw Hat", "slot": "helmet",
    "art": { "type": "hat", "color": "#ecd9a0", "trim": "#c8323c" },
    "stats": { "defense": 1 },
    "description": "Perfect for farming. Terrible for war."
  },
  "cooking_pot": {
    "name": "Cooking Pot", "slot": "helmet",
    "art": { "type": "pot", "color": "#55555f", "trim": "#2b2b33" },
    "stats": { "defense": 15 },
    "description": "Technically a helmet if you believe hard enough."
  },
  "gold_crown": {
    "name": "Golden Crown", "slot": "helmet",
    "art": { "type": "crown", "color": "#f2c14e", "trim": "#e8505b" },
    "stats": { "maxHp": 100 },
    "description": "Gives no protection, but tons of confidence."
  },
  "mayor_hat": {
    "name": "Mayoral Top Hat", "slot": "helmet",
    "art": { "type": "tophat", "color": "#2b2b33", "trim": "#c8323c" },
    "stats": { "maxHp": 10 },
    "description": "Adds 3 feet of authority. Removes all common sense."
  },
  "round_shield": {
    "name": "Round Shield", "slot": "shield",
    "art": { "type": "round", "color": "#a8814f", "trim": "#9aa0a8" },
    "stats": { "defense": 40 },
    "description": "Round. Shieldy. Does what it says."
  },
  "knight_shield": {
    "name": "Knight's Shield", "slot": "shield",
    "art": { "type": "kite", "color": "#3f6fb4", "trim": "#f2c14e" },
    "stats": { "defense": 80 },
    "description": "Borrowed from a knight. Permanently."
  },
  "barn_door": {
    "name": "Barn Door", "slot": "shield",
    "art": { "type": "door", "color": "#b5503a", "trim": "#f4f1e8" },
    "stats": { "defense": 200, "speed": -20 },
    "description": "Somewhere, a barn is very cold right now."
  },
  // ---- Crafted at Brunhilde's forge (see data/recipes.js) ----
  "goo_sword": {
    "name": "Sticky Sword", "slot": "weapon",
    "art": { "type": "sword", "color": "#6dd36d", "trim": "#3f8f3a" },
    "stats": { "attack": 35 },
    "description": "Made of slime. Very sharp. Very sticky. Do not lick."
  },
  "slime_shield": {
    "name": "Slime Shield", "slot": "shield",
    "art": { "type": "round", "color": "#6dd36d", "trim": "#3f8f3a" },
    "stats": { "defense": 45 },
    "description": "Arrows bounce off. So do friends."
  },
  "feather_cape": {
    "name": "Goose Down Cape", "slot": "cape",
    "art": { "type": "cape", "color": "#f4f1e8", "trim": "#d8d8e0" },
    "stats": { "speed": 20, "maxHp": 30 },
    "description": "Incredibly fluffy. Occasionally honks."
  },
  "hide_armor": {
    "name": "Boar Hide Armour", "slot": "armor",
    "art": { "type": "leather", "color": "#6b4428", "trim": "#c99560" },
    "stats": { "defense": 60, "speed": -5 },
    "description": "Heavy, warm, and it still smells angry."
  },
  "tusk_spear": {
    "name": "Tusk Spear", "slot": "weapon",
    "art": { "type": "spear", "color": "#f4f1e8", "trim": "#7a5232" },
    "stats": { "attack": 90 },
    "description": "Pointy at one end. Gooey at the other."
  },

  "pelt_cape": {
    "name": "Wolf Pelt Cape", "slot": "cape",
    "art": { "type": "cape", "color": "#7a7f88", "trim": "#4a4f58" },
    "stats": { "defense": 25, "maxHp": 60 },
    "description": "Warm, fluffy, and only slightly haunted by a wolf."
  },
  "crab_shield": {
    "name": "Crab Shell Shield", "slot": "shield",
    "art": { "type": "round", "color": "#e8642c", "trim": "#b5300f" },
    "stats": { "defense": 120 },
    "description": "Still pinches occasionally. Nobody knows how."
  },
  "ember_blade": {
    "name": "Ember Blade", "slot": "weapon",
    "art": { "type": "sword", "color": "#ffb23a", "trim": "#b5300f" },
    "stats": { "attack": 350 },
    "description": "Permanently on fire. Do not sheathe. Do not hug."
  },
  "dragon_armor": {
    "name": "Dragonscale Armour", "slot": "armor",
    "art": { "type": "plate", "color": "#a8302c", "trim": "#f2c14e" },
    "stats": { "defense": 500, "maxHp": 300, "speed": -10 },
    "description": "Made from the dragon's old scales. It's fine. It was shedding anyway."
  },
  "dragon_tooth_sword": {
    "name": "Dragon Tooth Sword", "slot": "weapon",
    "art": { "type": "sword", "color": "#f4f1e8", "trim": "#a8302c" },
    "stats": { "attack": 1500 },
    "description": "Pulled from a dragon. The dragon was not consulted."
  },
  "godslayer": {
    "name": "The Godslayer (Probably)", "slot": "weapon",
    "art": { "type": "staff", "color": "#f2c14e", "trim": "#9b7bff" },
    "stats": { "attack": 9000, "maxHp": 500 },
    "description": "Forged from ancient shards and dragon bits. Might be strong enough. Might."
  },

  // ---- Monster bits (dropped in the Plains) ----
  "slime_goo": {
    "name": "Slime Goo", "slot": "material", "stack": true,
    "art": { "type": "goo", "color": "#6dd36d", "trim": "#3f8f3a" },
    "description": "Wobbly. Warm. Why is it warm?"
  },
  "goose_feather": {
    "name": "Goose Feather", "slot": "material", "stack": true,
    "art": { "type": "feather", "color": "#f4f1e8", "trim": "#d8d8e0" },
    "description": "Still angry, somehow."
  },
  "boar_hide": {
    "name": "Boar Hide", "slot": "material", "stack": true,
    "art": { "type": "hide", "color": "#8a5a2b", "trim": "#6b4428" },
    "description": "Tough leather. The boar would like it back."
  },
  "boar_tusk": {
    "name": "Boar Tusk", "slot": "material", "stack": true,
    "art": { "type": "tusk", "color": "#f4f1e8", "trim": "#d8d0b8" },
    "description": "A very pointy tooth. Good for spears."
  },

  // ---- Monster bits (the wider world) ----
  "wolf_pelt": {
    "name": "Wolf Pelt", "slot": "material", "stack": true,
    "art": { "type": "hide", "color": "#7a7f88", "trim": "#4a4f58" },
    "description": "Fluffy. Smells like adventure and wet dog."
  },
  "crab_shell": {
    "name": "Crab Shell", "slot": "material", "stack": true,
    "art": { "type": "goo", "color": "#e8642c", "trim": "#b5300f" },
    "description": "Hard, orange, and still a bit snippy."
  },
  "ember_core": {
    "name": "Ember Core", "slot": "material", "stack": true,
    "art": { "type": "goo", "color": "#ffb23a", "trim": "#e8541c" },
    "description": "Hot. Very hot. Why is it in your bag."
  },
  "dragon_scale": {
    "name": "Dragon Scale", "slot": "material", "stack": true,
    "art": { "type": "hide", "color": "#a8302c", "trim": "#f2c14e" },
    "description": "Fireproof, shiny, and extremely smug."
  },
  "ancient_shard": {
    "name": "Ancient Shard", "slot": "material", "stack": true,
    "art": { "type": "tusk", "color": "#9b7bff", "trim": "#d8c8ff" },
    "description": "Hums with old power. And a little bit of disappointment."
  },

  "hero_cape": {
    "name": "Spare Hero Cape", "slot": "cape",
    "art": { "type": "cape", "color": "#c8323c", "trim": "#8e1f2a" },
    "stats": { "speed": 10, "maxHp": 25 },
    "description": "Makes anyone feel like the main character. Dangerous."
  }
};
