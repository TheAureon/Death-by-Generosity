// ===========================================================================
// THE HERO — the cursed, absurdly overpowered player. Safe to edit.
// ===========================================================================
DBG.data.hero = {
  "name": "Sir Givesalot",

  // Core numbers used by the game
  "maxHp": 99999,
  "regenPerSecond": 2500,  // HP healed every second, always
  "attack": 9999,
  "defense": 999,          // incoming damage is reduced by this (minimum 1)
  "thorns": 10,            // attackers take this many times their own hit back
  "moveSpeed": 90,         // (overrides settings.playerSpeed)
  "selfPunchRegenPause": 3, // seconds regen stops after punching yourself (K)

  // The armour that can't be taken off
  "armor": {
    "name": "Cursed Plate of Eternal Coziness",
    "description": "Cannot be removed. You have tried. The armour has also tried. It likes you."
  },

  // What's in the bag when the game starts (ids from data/items.js)
  "startingInventory": [
    "rusty_sword", "legendary_sword", "war_axe", "frying_pan", "wet_fish", "wizard_staff",
    "pointy_spear", "leather_vest", "plate_armor", "wizard_robe", "iron_helm", "straw_hat",
    "cooking_pot", "gold_crown", "round_shield", "knight_shield", "barn_door", "hero_cape"
  ],
  "inventorySize": 32,

  // Extra lines shown on the character sheet (press C). Pure comedy.
  "sheetStats": [
    ["Strength", "9,999"],
    ["Dexterity", "Yes"],
    ["Luck", "Suspiciously high"],
    ["Wisdom", "1"],
    ["Humility", "0"],
    ["Ways to die", "Searching..."]
  ]
};
