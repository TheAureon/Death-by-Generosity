// ---------------------------------------------------------------------------
// The player: the cursed, overpowered hero.
//   - Walking with WASD / arrow keys, 8 directions, walk animation, shadow
//   - Stats from data/hero.js: huge HP, constant regen, defense, thorns
//   - K = punch yourself (it never works, but it's a nice way to see regen)
//   - F = attack directly (flattens people; counts as a wasted attempt)
// Tells the UI about health changes with game event "hero-hp".
// ---------------------------------------------------------------------------
(function () {
  // Standing frame for each facing (see src/art/characterArt.js)
  const IDLE_FRAME = { down: 0, up: 3, side: 6 };

  class Player extends Phaser.Physics.Arcade.Sprite {
    constructor(scene, x, y) {
      super(scene, x, y, "hero", 0);
      scene.add.existing(this);
      scene.physics.add.existing(this);

      // Position = the hero's feet, which makes depth-sorting natural.
      this.setOrigin(0.5, 1);
      // Only the feet collide (so the head can overlap a wall top, Stardew-style).
      this.body.setSize(10, 6).setOffset(3, 17);
      this.setCollideWorldBounds(true);

      this.shadow = scene.add.image(x, y, "shadow").setOrigin(0.5, 0.6);
      this.facing = "down";

      // --- Stats ---
      const h = DBG.data.hero;
      this.isHero = true;
      this.alive = true;
      this.name = h.name;
      this.stats = { maxHp: h.maxHp, regen: h.regenPerSecond, attack: h.attack, defense: h.defense, thorns: h.thorns };
      this.hp = h.maxHp;
      this.speed = h.moveSpeed || DBG.data.settings.playerSpeed;
      this.selfPunchCount = 0;

      const K = Phaser.Input.Keyboard.KeyCodes;
      this.keys = scene.input.keyboard.addKeys({
        up: K.W, down: K.S, left: K.A, right: K.D,
        up2: K.UP, down2: K.DOWN, left2: K.LEFT, right2: K.RIGHT,
      });
      scene.input.keyboard.on("keydown-K", this.punchSelf, this);
      scene.input.keyboard.on("keydown-F", this.strike, this);
      this.strikeReadyAt = 0;

      this.emitHp();
    }

    /**
     * Damage from any source. If it ever gets the hero to 0 HP... that's it.
     * That's the ending. Whoever did it (`source`) gets the credit.
     */
    takeDamage(amount, source) {
      if (!this.alive) return;
      this.hp -= amount;
      this.setTintFill(0xffffff);
      this.scene.time.delayedCall(80, () => this.active && this.alive && this.clearTint());
      if (this.hp <= 0) {
        this.hp = 0;
        this.emitHp();
        this.alive = false;
        this.scene.heroDied(source);
        return;
      }
      this.emitHp();
    }

    /**
     * K: punch yourself in the face. Leaves you at 1 HP, and your regen
     * sulks for a few seconds — a window where something strong enough
     * could actually finish the job.
     */
    punchSelf() {
      if (!this.alive || this.scene.time.now < (this.punchReadyAt || 0)) return;
      this.punchReadyAt = this.scene.time.now + 1000;
      const lines = DBG.data.jokes.selfPunch;
      this.hp = 1;
      this.regenPause = DBG.data.hero.selfPunchRegenPause || 3;
      DBG.Sfx.play("selfpunch");
      this.emitHp();
      this.scene.cameras.main.shake(150, 0.01);
      this.setTintFill(0xff4444);
      this.scene.time.delayedCall(120, () => this.clearTint());
      DBG.Combat.popNumber(this.scene, this, "-" + DBG.Combat.fmt(this.stats.maxHp - 1), DBG.Combat.COLORS.hero);
      this.scene.game.events.emit("toast", lines[this.selfPunchCount++ % lines.length]);
    }

    /**
     * F: attack directly. You CAN... but anyone you hit is instantly
     * flattened, and it doesn't help you die. WorldScene decides what's hit.
     */
    strike() {
      const s = this.scene;
      if (!this.alive || s.time.now < this.strikeReadyAt) return;
      DBG.Sfx.play("swoosh");
      this.strikeReadyAt = s.time.now + 350;
      const dir = this.facing === "side" ? { x: this.flipX ? 1 : -1, y: 0 } : { x: 0, y: this.facing === "up" ? -1 : 1 };
      const cx = this.x + dir.x * 14, cy = this.y - 8 + dir.y * 14;
      // Swipe effect
      const fx = s.add.image(cx, cy, "slash").setDepth(this.y + 5).setAlpha(0.9)
        .setAngle(dir.x > 0 ? 0 : dir.x < 0 ? 180 : dir.y > 0 ? 90 : -90);
      s.tweens.add({ targets: fx, alpha: 0, scale: 1.3, duration: 180, onComplete: () => fx.destroy() });
      s.events.emit("hero-strike", { x: cx, y: cy, radius: 16, damage: this.stats.attack });
    }

    emitHp() {
      this.scene.game.events.emit("hero-hp", this.hp, this.stats.maxHp, this.stats.regen);
    }

    /** Called every frame by the scene. dt = seconds since last frame. */
    update(dt) {
      if (!this.alive) { this.setVelocity(0, 0); return; }
      // --- Constant regen (unless it's sulking after a self-punch) ---
      if (this.regenPause > 0) this.regenPause -= dt;
      else if (this.hp < this.stats.maxHp) {
        this.hp = Math.min(this.stats.maxHp, this.hp + this.stats.regen * dt);
        this.emitHp();
      }

      // --- Movement ---
      const k = this.keys;
      let dx = 0, dy = 0;
      if (k.left.isDown || k.left2.isDown) dx -= 1;
      if (k.right.isDown || k.right2.isDown) dx += 1;
      if (k.up.isDown || k.up2.isDown) dy -= 1;
      if (k.down.isDown || k.down2.isDown) dy += 1;

      // Same speed diagonally as straight
      const len = Math.hypot(dx, dy) || 1;
      this.setVelocity((dx / len) * this.speed, (dy / len) * this.speed);

      if (dx !== 0 || dy !== 0) {
        // Sideways wins over up/down when moving diagonally
        if (dx !== 0) this.facing = "side";
        else this.facing = dy < 0 ? "up" : "down";
        if (dx !== 0) this.setFlipX(dx > 0); // art faces left; flip to face right
        this.anims.play("hero-walk-" + this.facing, true);
      } else {
        this.anims.stop();
        this.setFrame(IDLE_FRAME[this.facing]);
      }

      this.setDepth(this.y);
      this.shadow.setPosition(this.x, this.y).setDepth(this.y - 0.5);
    }
  }

  DBG.Entities.Player = Player;
})();
