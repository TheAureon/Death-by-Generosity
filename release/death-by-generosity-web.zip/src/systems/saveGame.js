// ---------------------------------------------------------------------------
// Saving and loading. One save slot, stored in the browser (localStorage),
// so it survives closing the tab. Nothing is sent anywhere.
//
//   DBG.Save.fresh()     — a brand new game state
//   DBG.Save.save()      — write the current game to the save slot
//   DBG.Save.load()      — read the save slot (or null)
//   DBG.Save.apply(data) — make a loaded save the current game
//   DBG.Save.autosave()  — save soon (called after gifts, deaths, map changes)
// ---------------------------------------------------------------------------
DBG.Save = {
  KEY: "death-by-generosity-save-v1",

  /** A brand new game: starting bag, empty tally, fresh world memory. */
  fresh() {
    const hero = DBG.data.hero;
    DBG.state.inventory = new DBG.Inventory(hero.inventorySize || 32, hero.startingInventory || []);
    DBG.state.tally = { gifted: 0, wasted: 0 };
    DBG.state.world = { npcs: {}, pickups: {} };
    DBG.state.introShown = false;
    DBG.state.mapId = DBG.data.settings.startMap;
    DBG.state.pos = null;
    DBG.state.waystones = {}; // map id -> true once you've touched its waystone
    DBG.state.warned = {};    // road warnings already shown
    DBG.state.playSeconds = 0;
    DBG.state.giftsGiven = 0;
    DBG.state.dead = false;
  },

  /** Everything worth keeping, as plain data. */
  snapshot() {
    const world = DBG.game && DBG.game.scene.getScene("World");
    if (world && world.sys.isActive() && world.player) {
      world.rememberPickups(); // items on the ground right now
      DBG.state.mapId = world.map.id;
      DBG.state.pos = { x: Math.round(world.player.x), y: Math.round(world.player.y) };
    }
    const inv = DBG.state.inventory;
    return {
      version: 2,
      savedAt: new Date().toISOString(),
      mapId: DBG.state.mapId,
      pos: DBG.state.pos,
      inventory: { slots: inv.slots.slice(), counts: inv.counts.slice() },
      tally: { ...DBG.state.tally },
      introShown: DBG.state.introShown,
      waystones: { ...DBG.state.waystones },
      warned: { ...DBG.state.warned },
      playSeconds: Math.round(DBG.state.playSeconds || 0),
      giftsGiven: DBG.state.giftsGiven || 0,
      world: JSON.parse(JSON.stringify(DBG.state.world)),
    };
  },

  save() {
    if (DBG.state.dead) return false; // you died: this run is over
    try {
      localStorage.setItem(this.KEY, JSON.stringify(this.snapshot()));
      if (DBG.game) DBG.game.events.emit("saved");
      return true;
    } catch (e) {
      console.warn("Could not save:", e);
      return false;
    }
  },

  load() {
    try {
      const raw = localStorage.getItem(this.KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      console.warn("Could not read the save:", e);
      return null;
    }
  },

  exists() {
    return !!this.load();
  },

  wipe() {
    try { localStorage.removeItem(this.KEY); } catch (e) { /* nothing to wipe */ }
  },

  /** Make a loaded save the current game. Unknown items/maps are skipped. */
  apply(data) {
    this.fresh();
    const inv = DBG.state.inventory;
    (data.inventory.slots || []).forEach((id, i) => {
      if (id && DBG.data.items[id] && i < inv.slots.length) { inv.slots[i] = id; inv.counts[i] = data.inventory.counts[i] || 1; }
    });
    DBG.state.tally = { gifted: 0, wasted: 0, ...data.tally };
    DBG.state.introShown = !!data.introShown;
    DBG.state.waystones = { ...(data.waystones || {}) };
    DBG.state.warned = { ...(data.warned || {}) };
    DBG.state.playSeconds = data.playSeconds || 0;
    DBG.state.giftsGiven = data.giftsGiven || 0;
    DBG.state.world = { npcs: {}, pickups: {}, ...data.world };
    if ((data.version || 1) < 2) this.upgradeToOpenWorld(data);
    // Drop gear that no longer exists in data/items.js (e.g. after editing)
    Object.values(DBG.state.world.npcs).forEach((rec) => {
      rec.gear = (rec.gear || []).filter((id) => DBG.data.items[id]);
      rec.hoard = (rec.hoard || []).filter((id) => DBG.data.items[id]);
    });
    const known = data.mapId === "world" || DBG.data.maps[data.mapId];
    DBG.state.mapId = known ? data.mapId : DBG.data.settings.startMap;
    DBG.state.pos = DBG.state.mapId === data.mapId ? data.pos : null;
  },

  /**
   * Saves from before the open world were per-area. Move the hero and any
   * items lying around to the same spots in the big stitched world.
   */
  upgradeToOpenWorld(data) {
    const W = DBG.data.world, S = DBG.data.settings.tileSize;
    // How far each old area got shifted inside its 64x48 piece (in tiles)
    const PAD = { village: [2, 3], plains: [6, 6], lake: [9, 7], forest: [9, 7], city: [7, 5],
      guardtown: [9, 7], fortress: [9, 6], lava: [9, 7], dragon: [10, 3], ancient: [12, 5] };
    const shift = (id) => {
      const cy = W.layout.findIndex((row) => row.includes(id));
      if (cy < 0 || !PAD[id]) return null;
      const cx = W.layout[cy].indexOf(id);
      return { x: (cx * W.cellWidth + PAD[id][0]) * S, y: (cy * W.cellHeight + PAD[id][1]) * S };
    };
    const pickups = DBG.state.world.pickups;
    const moved = pickups.world || [];
    Object.keys(pickups).forEach((id) => {
      const d = shift(id);
      if (!d) return;
      pickups[id].forEach((p) => moved.push({ ...p, x: p.x + d.x, y: p.y + d.y }));
      delete pickups[id];
    });
    pickups.world = moved;
    const d = shift(data.mapId);
    data.pos = d && data.pos ? { x: data.pos.x + d.x, y: data.pos.y + d.y } : null;
    data.mapId = "world";
  },

  /** Save a moment from now (several events in a row = one save). */
  autosave() {
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this.save(), 800);
  },
};
